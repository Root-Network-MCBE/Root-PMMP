<?php

/*
 *
 *  ____            _        _   __  __ _                  __  __ ____
 * |  _ \ ___   ___| | _____| |_|  \/  (_)_ __   ___      |  \/  |  _ \
 * | |_) / _ \ / __| |/ / _ \ __| |\/| | | '_ \ / _ \_____| |\/| | |_) |
 * |  __/ (_) | (__|   <  __/ |_| |  | | | | | |  __/_____| |  | |  __/
 * |_|   \___/ \___|_|\_\___|\__|_|  |_|_|_| |_|\___|     |_|  |_|_|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author PocketMine Team
 * @link http://www.pocketmine.net/
 *
 *
 */

declare(strict_types=1);

namespace pocketmine\crafting\json;

use function count;

final class ItemStackData implements \JsonSerializable{

	/** @required */
	public string $name;

	public int $count;
	public string $block_states;
	public int $meta;
	public string $nbt;
	/** @var string[] */
	public array $can_place_on;
	/** @var string[] */
	public array $can_destroy;

	public function __construct(string $name){
		$this->name = $name;
	}

	/**
	 * @return mixed[]|string
	 */
	public function jsonSerialize() : array|string{
		$result = (array) $this;
		if(count($result) === 1 && isset($result["name"])){
			return $this->name;
		}
		return $result;
	}
}
