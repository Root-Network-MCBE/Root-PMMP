<?php

/*
 *
 *  ____            _        _   __  __ _                  __  __ ____
 * |  _ \ ___   ___| | _____| |_|  \/  (_)_ __   ___      |  \/  |  _ \
 * | |_) / _ \ / __| |/ / _ \ __| |\/| | | '_ \ / _ \_____| |\/| | |_) |
 * |  __/ (_) | (__|   <  __/ |_| |  | | | | | |  __/_____| |  | |  __/
 * |_|   \___/ \___|_|\_\___|\__|_|  |_|_|_| |_|\___|     |_|  |_|_|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author PocketMine Team
 * @link http://www.pocketmine.net/
 *
 *
 */

declare(strict_types=1);

namespace pocketmine\block;

use pocketmine\block\tile\Hopper as TileHopper;
use pocketmine\block\utils\HopperTransferHelper;
use pocketmine\block\utils\PoweredByRedstoneTrait;
use pocketmine\block\utils\SupportType;
use pocketmine\data\runtime\RuntimeDataDescriber;
use pocketmine\entity\object\ItemEntity;
use pocketmine\event\block\HopperActionEvent;
use pocketmine\event\block\HopperPickupItemEvent;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\math\AxisAlignedBB;
use pocketmine\math\Facing;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\world\BlockTransaction;
use function assert;
use function count;
use function max;
use function min;

class Hopper extends Transparent implements HopperInteractable{
	use PoweredByRedstoneTrait;

	public const TRANSFER_COOLDOWN = 8;
	public const ENTITY_PICKUP_COOLDOWN = 8;

	public const TRANSFER_PER_ACTION = 1;

	public const ENTITY_PICKUP_PER_ACTION = 1;

	private int $facing = Facing::DOWN;

	private int $lastTransferActionTick = 0;
	private int $lastEntityPickupTick = 0;
	private AxisAlignedBB $pickingBox;

	protected function describeBlockOnlyState(RuntimeDataDescriber $w) : void{
		$w->facingExcept($this->facing, Facing::UP);
		$w->bool($this->powered);
	}

	public function readStateFromWorld() : Block{
		parent::readStateFromWorld();
		$tile = $this->position->getWorld()->getTile($this->position);
		if($tile instanceof TileHopper){
			$this->lastTransferActionTick = $this->position->getWorld()->getServer()->getTick() - $tile->getTransferCooldown();
		}
		return $this;
	}

	public function writeStateToWorld() : void{
		parent::writeStateToWorld();
		$tile = $this->position->getWorld()->getTile($this->position);
		assert($tile instanceof TileHopper);
		$tile->setTransferCooldown($this->position->getWorld()->getServer()->getTick() - $this->lastTransferActionTick);
	}

	public function getFacing() : int{ return $this->facing; }

	/** @return $this */
	public function setFacing(int $facing) : self{
		if($facing === Facing::UP){
			throw new \InvalidArgumentException("Hopper may not face upward");
		}
		$this->facing = $facing;
		return $this;
	}

	protected function recalculateCollisionBoxes() : array{
		$result = [
			AxisAlignedBB::one()->trim(Facing::UP, 6 / 16)
		];

		foreach(Facing::HORIZONTAL as $f){
			$result[] = AxisAlignedBB::one()->trim($f, 14 / 16);
		}
		return $result;
	}

	public function getSupportType(int $facing) : SupportType{
		return match($facing){
			Facing::UP => SupportType::FULL,
			Facing::DOWN => $this->facing === Facing::DOWN ? SupportType::CENTER : SupportType::NONE,
			default => SupportType::NONE
		};
	}

	public function place(BlockTransaction $tx, Item $item, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, ?Player $player = null) : bool{
		$this->facing = $face === Facing::DOWN ? Facing::DOWN : Facing::opposite($face);

		$world = $this->position->getWorld();
		$this->updateTransferCooldown();
		$this->updateEntityPickingCooldown();
		$world->scheduleDelayedBlockUpdate($this->position, $this->getNextTickUpdate());

		return parent::place($tx, $item, $blockReplace, $blockClicked, $face, $clickVector, $player);
	}

	public function onInteract(Item $item, int $face, Vector3 $clickVector, ?Player $player = null, array &$returnedItems = []) : bool{
		if($player !== null){
			$tile = $this->position->getWorld()->getTile($this->position);
			if($tile instanceof TileHopper){
				$player->setCurrentWindow($tile->getInventory());
			}
			return true;
		}
		return false;
	}

	protected function transferMultiple(Inventory $from, Inventory $to, int $count) : bool{
		$moved = false;
		$count = max(0, $count);
		for($i = 0; $i < $count; $i++){
			if(!HopperTransferHelper::transferOneItem($from, $to)){
				break;
			}
			$moved = true;
		}
		return $moved;
	}

	public function onScheduledUpdate() : void{
		$world = $this->position->getWorld();

		if (!$this->powered && !$this->isTransferInCooldown()) {
			$facingBlock = $this->getSide($this->facing);
			$pushSuccess = false;

			$ev = new HopperActionEvent($this, $facingBlock, HopperActionEvent::ACTION_PUSH);
			$ev->call();
			if (!$ev->isCancelled() && $facingBlock instanceof HopperInteractable) {
				for ($i = 0; $i < static::TRANSFER_PER_ACTION; $i++) {
					if (!$facingBlock->doHopperPush($this)) {
						break;
					}
					$pushSuccess = true;
				}
			}

			$topBlock = $this->getSide(Facing::UP);
			$pullSuccess = false;

			$ev = new HopperActionEvent($this, $topBlock, HopperActionEvent::ACTION_PULL);
			$ev->call();
			if (!$ev->isCancelled() && $topBlock instanceof HopperInteractable) {
				for ($i = 0; $i < static::TRANSFER_PER_ACTION; $i++) {
					if (!$topBlock->doHopperPull($this)) {
						break;
					}
					$pullSuccess = true;
				}
			}

			if ($pushSuccess || $pullSuccess) {
				$this->updateTransferCooldown();
			}
		}

		if (!$this->powered && !$this->isEntityPickingInCooldown()) {
			$currentTile = $world->getTile($this->position);
			if (!$currentTile instanceof TileHopper) {
				return;
			}

			foreach ($world->getNearbyEntities($this->getPickingBox()) as $entity) {
				if (!$entity instanceof ItemEntity) {
					continue;
				}

				if (HopperPickupItemEvent::hasHandlers()) {
					$ev = new HopperPickupItemEvent($entity, $this);
					$ev->call();
					if ($ev->isCancelled()) {
						continue;
					}
				}

				$stack = $entity->getItem();
				if ($stack->getCount() <= 0) {
					continue;
				}

				$toInsert = clone $stack;
				$ret = $currentTile->getInventory()->addItem($toInsert);

				if (count($ret) > 0) {
					$remaining = 0;
					foreach ($ret as $left) {
						$remaining += $left->getCount();
					}
					$entity->setStackSize($remaining);
				} else {
					$entity->flagForDespawn();
				}

				$this->updateEntityPickingCooldown();
				break;
			}
		}

		$world->scheduleDelayedBlockUpdate($this->position, $this->getNextTickUpdate());
	}

	public function doHopperPush(Hopper $hopperBlock) : bool{
		if($this->isTransferInCooldown()){
			return false;
		}

		$currentTile = $this->position->getWorld()->getTile($this->position);
		if(!$currentTile instanceof TileHopper){
			return false;
		}

		$tileHopper = $this->position->getWorld()->getTile($hopperBlock->position);
		if(!$tileHopper instanceof TileHopper){
			return false;
		}

		$ok = $this->transferMultiple(
			$tileHopper->getInventory(),
			$currentTile->getInventory(),
			static::TRANSFER_PER_ACTION
		);

		if($ok){
			$hopperBlock->updateTransferCooldown();
			return true;
		}

		return false;
	}

	public function doHopperPull(Hopper $hopperBlock) : bool{
		if($this->isTransferInCooldown()){
			return false;
		}

		$currentTile = $this->position->getWorld()->getTile($this->position);
		if(!$currentTile instanceof TileHopper){
			return false;
		}

		$tileHopper = $this->position->getWorld()->getTile($hopperBlock->position);
		if(!$tileHopper instanceof TileHopper){
			return false;
		}

		return $this->transferMultiple(
			$currentTile->getInventory(),
			$tileHopper->getInventory(),
			static::TRANSFER_PER_ACTION
		);
	}

	public function getPickingBox() : AxisAlignedBB{
		return $this->pickingBox ??= $this->recalculateBoundingBox();
	}

	protected function recalculateBoundingBox() : AxisAlignedBB{
		return AxisAlignedBB::one()->expand(0, 1, 0)->offset($this->position->x, $this->position->y, $this->position->z);
	}

	private function isTransferInCooldown() : bool{
		$currentTick = $this->position->getWorld()->getServer()->getTick();
		return $currentTick - $this->lastTransferActionTick < static::TRANSFER_COOLDOWN;
	}

	private function isEntityPickingInCooldown() : bool{
		$currentTick = $this->position->getWorld()->getServer()->getTick();
		return $currentTick - $this->lastEntityPickupTick < static::ENTITY_PICKUP_COOLDOWN;
	}

	private function updateTransferCooldown() : void{
		$this->lastTransferActionTick = $this->position->getWorld()->getServer()->getTick();
	}

	private function updateEntityPickingCooldown() : void{
		$this->lastEntityPickupTick = $this->position->getWorld()->getServer()->getTick();
	}

	private function getNextTickUpdate() : int{
		$currentTick = $this->position->getWorld()->getServer()->getTick();

		$nextTick = 1;
		if($this->isTransferInCooldown()){
			$nextTick = static::TRANSFER_COOLDOWN - ($currentTick - $this->lastTransferActionTick);
		}
		if($this->isEntityPickingInCooldown()){
			$nextTick = min($nextTick, static::ENTITY_PICKUP_COOLDOWN - ($currentTick - $this->lastEntityPickupTick));
		}

		return $nextTick;
	}

	//TODO: redstone logic
}
